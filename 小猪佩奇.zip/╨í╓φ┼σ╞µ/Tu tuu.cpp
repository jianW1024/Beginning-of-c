#include <stdio.h>
#include <graphics.h>
#include <conio.h>
#include <math.h>
#include <Vfw.h>
#pragma comment(lib,"Winmm.lib")
#pragma comment (lib, "Vfw32.lib")

#define High 417  // ����ߴ�
#define Width 626

char input='Q';
char home;

IMAGE dong1;//
IMAGE dong2;//
IMAGE timg;//

void vv()//������Ƶ
{

	initgraph(626, 416);
	BeginBatchDraw();
	HWND hwnd = MCIWndCreate(GetHWnd(), NULL, WS_CHILD | WS_VISIBLE | MCIWNDF_NOMENU | MCIWNDF_NOPLAYBAR, NULL);
	SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_SHOWWINDOW);
	MCIWndOpen(hwnd, "mainv.wmv", NULL);
	MCIWndPlay(hwnd);
	Sleep(5000);
	EndBatchDraw();
}


void maininterface()//������
{
mciSendString("open mainm.mp3 alias mainm", NULL, 0, NULL);//����������
	mciSendString("play mainm", NULL, 0, NULL);
IMAGE main_p;//����ͼƬ��
loadimage(&main_p, "mainp.png");//װ��ͼƬ
loadimage(&dong1, "dong1.png");//װ��ͼƬ
loadimage(&dong2, "dong2.png");//װ��ͼƬ
loadimage(&timg, "timg.png");//װ��ͼƬ
putimage(0, 0, &main_p);//���ͼƬ�������棩

	while (input != 'w'&&input != 'a'&&input != 's'&&input != 'd')
	{
		input = getch();
	}
	closegraph();
}

main()
{
	vv();
begin:initgraph(Width, High);
	  maininterface();
	if (input == 'w')//xiaozhupeiqi dongdongshou
	{
input = 'e';
while(home !=27)
{
initgraph(Width, High);
putimage(0, 0, &dong1);
home=getch();

}
home=12;
		goto begin;
	}
	else if (input == 'a')//xiaozhupeiqi dongdongjiao
	{
		input = 'e';
initgraph(Width, High);
		while(home !=27)
{
//BeginBatchDraw();
putimage(0, 0, &dong1);
Sleep(100);
putimage(0, 0, &dong2);
Sleep(90);
//EndBatchDraw();
home=getch();
}
home=12;
		goto begin;
	}
	else if (input == 's')//xiaozhupeiqi tioatiao
	{
		input = 'e';
initgraph(960, 540);
putimage(0, 0, &timg);
		while (home != 27)
		{
			home = getch();
		}
		goto begin;
	}
	else if (input == 'd')//�˳�
	{
		exit(0);
	}
}